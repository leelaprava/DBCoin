package com.solution.database.Model;

public class Favorite {
	private String ticker_symbol;
	private String username;
	public String getTicker_symbol() {
		return ticker_symbol;
	}
	public void setTicker_symbol(String ticker_symbol) {
		this.ticker_symbol = ticker_symbol;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	

}
